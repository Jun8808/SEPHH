clear all
clc

landsea = ncread('H:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');

prec = ncread('H:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\MSWEPv2_prec_2p5deg.nc', 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*42),[144 72 365 41]),3),4); % 1980.1.1-2020.12.31
clear prec
%--------------------------------------------------------------------------
diri = 'H:\WORKS\30-Comp_EPHH\ERA5\Me_mon_2p5deg\';
%ncdisp('ERA5_Me_2p5deg.nc')
lat = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lat');
lon = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lon');

Me_obs  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Me');
Me_obs  = reshape(Me_obs,[size(Me_obs,1) size(Me_obs,2) 12 size(Me_obs,3)/12]);
Me_obs  = squeeze(mean(Me_obs(:,:,:,2:46),3))/1000; % KJ kg-1
%--------------------------------------------------------------------------
Me_piCTL = ncread('piControl_me.nc', 'Me_piCTL');
Me_piCTL = Me_piCTL/1000; % KJ kg-1
%--------------------------------------------------------------------------
diri0    = 'H:\WORKS\30-Comp_EPHH\CMIP6\historical2\';
diri1    = 'H:\WORKS\30-Comp_EPHH\CMIP6\historical2_me\';

models   = {'ACCESS-CM2','ACCESS-ESM1-5','CanESM5','CMCC-ESM2','CNRM-CM6-1',...
            'CNRM-CM6-1-HR','CNRM-ESM2-1','EC-Earth3','EC-Earth3-CC','EC-Earth3-Veg',...
            'EC-Earth3-Veg-LR','FGOALS-g3','GFDL-CM4','GFDL-ESM4','HadGEM3-GC31-LL',...
            'HadGEM3-GC31-MM','INM-CM5-0','IPSL-CM6A-LR','KACE-1-0-G',...
            'MIROC6','MIROC-ES2L','MPI-ESM1-2-HR','MPI-ESM1-2-LR',...
            'MRI-ESM2-0','NorESM2-LM','NorESM2-MM','TaiESM1','UKESM1-0-LL'};

lon      = ncread(strcat(diri0, 'ACCESS-CM2_historical.nc'), 'lon'); 
lat      = ncread(strcat(diri0, 'ACCESS-CM2_historical.nc'), 'lat');

lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);

for m = 1:length(models)

fs0    = dir(strcat(diri0,models{m},'_historical.nc'));
fs1    = dir(strcat(diri1,models{m},'_historical.nc'));

f0     = strcat(diri0,fs0.name);
f1     = strcat(diri1,fs1.name);

comp_pr_ann(:,:,:,m)  = ncread(f0,'comp_pr_ann');
Me(:,:,:,m)           = ncread(f1,'Me')/1000;
disp(m)
end
%**************************************************************************
landsea    = reshape(landsea,[144*72 1]);
prec_clim  = reshape(prec_clim,[144*72 1]);

Me_obs     = reshape(Me_obs,[size(Me_obs,1)*size(Me_obs,2) size(Me_obs,3)]);
Me_piCTL   = reshape(Me_piCTL,[size(Me_piCTL,1)*size(Me_piCTL,2) size(Me_piCTL,3) size(Me_piCTL,4)]);
Me         = reshape(Me,[size(Me,1)*size(Me,2) size(Me,3) size(Me,4)]);
comp_pr_ann  = reshape(comp_pr_ann,[size(comp_pr_ann,1)*size(comp_pr_ann,2) size(comp_pr_ann,3) size(comp_pr_ann,4)]);

lct    = find(landsea==1&prec_clim>100&lat1d>=-60);
weight = cos(pi*lat1d(lct)/180.0);
weight = weight/mean(weight);


Me_obs       = mean(Me_obs(lct,:).*repmat(weight,[1 45]),1);
Me_piCTL     = squeeze(mean(Me_piCTL(lct,:,:).*repmat(weight,[1 50 180]),1));
Me           = squeeze(mean(Me(lct,:,:).*repmat(weight,[1 121 28]),1));
comp_pr_ann  = squeeze(mean(comp_pr_ann(lct,:,:).*repmat(weight,[1 121 28]),1));

b = polyfit(1980:2024,Me_obs,1);
Me_obs_trd   = b(1)*10;

for k = 1:180
    b = polyfit(1980:2024,squeeze(Me_piCTL(1:45,k)),1);
    Me_piCTL_trd(k) = b(1)*10;
    clear b
end

for k = 1:28
    b = polyfit(1980:2024,squeeze(Me(1:45,k)),1);
    Me_trd(k) = b(1)*10;
    clear b
end
%**************************************************************************
comp_pr_ann_diff = squeeze(mean(comp_pr_ann(61:81,:),1)-mean(comp_pr_ann(1:21,:),1));

[r,p] = corrcoef(Me_trd,comp_pr_ann_diff);
corr_Me_pr   = r(1,2);
corr_Me_pr_p = p(1,2);

mean_z = mean(comp_pr_ann_diff);
std_z  = std(comp_pr_ann_diff);

mean_x = mean(Me_trd);
std_x  = std(Me_trd);

mean_y = Me_obs_trd;
std_y  = std(Me_piCTL_trd);

mean_z_y = mean_z+r(1,2)*std_z*std_x*(mean_y-mean_x)/(std_x^2+std_y^2);
std_z_y  = std_z*sqrt(1-r(1,2)^2/(1+std_y^2/std_x^2));
rrv      = (1-std_z_y^2/std_z^2)*100;
% (mean(comp_pr_ann_diff) - mean_z_y)/mean(comp_pr_ann_diff)
%**************************************************************************
plot(Me_trd,comp_pr_ann_diff,'o','MarkerFaceColor','k','MarkerEdgeColor','k')
xlim([0.4 1.2])
ylim([0 30])
hold on
b = polyfit(Me_trd,comp_pr_ann_diff,1);
plot([min(Me_trd) max(Me_trd)],[min(Me_trd) max(Me_trd)]*b(1)+b(2),'k-','LineWidth',3)
hold on
plot([Me_obs_trd,Me_obs_trd],[0,30],'c-','LineWidth',2)
hold on
plot([0],[mean(comp_pr_ann_diff)],'o','MarkerFaceColor','k','MarkerEdgeColor','k','MarkerSize',10)
hold on

y = mean_y-0.5:0.005:mean_y+0.5;
pdf_y = normpdf(y,mean_y,std_y);
plot(y,pdf_y,'k')
hold on

z_y = mean_z_y-0.5:0.005:mean_z_y+0.5;
pdf_z_y = normpdf(z_y,mean_z_y,std_z_y);
plot(pdf_z_y*0.1,z_y,'k')
hold on

plot([mean_y-1.65*std_y,mean_y-1.65*std_y],[0,3],'c--','LineWidth',1)
hold on
plot([mean_y+1.65*std_y,mean_y+1.65*std_y],[0,3],'c--','LineWidth',1)
hold on

plot([0,3],[mean_z_y-1.65*std_z_y,mean_z_y-1.65*std_z_y],'r--','LineWidth',1)
hold on
plot([0,3],[mean_z_y+1.65*std_z_y,mean_z_y+1.65*std_z_y],'r--','LineWidth',1)
%**************************************************************************
myncid = netcdf.create('fig4a.nc', 'NC_NOCLOBBER');
dimid0 = netcdf.defDim(myncid, 'obs', 1);
dimid1 = netcdf.defDim(myncid, 'models', 28);
dimid2 = netcdf.defDim(myncid, 'pdfs', length(pdf_y));
dimid3 = netcdf.defDim(myncid, 'stats', 5);
varid0 = netcdf.defVar(myncid, 'Me_obs_trd', 'double', [dimid0]);
varid11 = netcdf.defVar(myncid, 'Me_trd', 'double', [dimid1]);
varid12 = netcdf.defVar(myncid, 'comp_pr_ann_diff', 'double', [dimid1]);
varid21 = netcdf.defVar(myncid, 'y', 'double', [dimid2]);
varid22 = netcdf.defVar(myncid, 'z_y', 'double', [dimid2]);
varid23 = netcdf.defVar(myncid, 'pdf_y', 'double', [dimid2]);
varid24 = netcdf.defVar(myncid, 'pdf_z_y', 'double', [dimid2]);
varid31 = netcdf.defVar(myncid, 'stats_y', 'double', [dimid3]);
varid32 = netcdf.defVar(myncid, 'stats_z_y', 'double', [dimid3]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid0, Me_obs_trd);
netcdf.putVar(myncid, varid11, Me_trd);
netcdf.putVar(myncid, varid12, comp_pr_ann_diff);
netcdf.putVar(myncid, varid21, y);
netcdf.putVar(myncid, varid22, z_y);
netcdf.putVar(myncid, varid23, pdf_y);
netcdf.putVar(myncid, varid24, pdf_z_y);
netcdf.putVar(myncid, varid31, [mean_y-1.65*std_y,mean_y-0.68*std_y,mean_y,mean_y+0.68*std_y,mean_y+1.65*std_y]);
netcdf.putVar(myncid, varid32, [mean_z_y-1.65*std_z_y,mean_z_y-0.68*std_z_y,mean_z_y,mean_z_y+0.68*std_z_y,mean_z_y+1.65*std_z_y]);
netcdf.close(myncid);
