% 2.5 deg, 1981-2020, Theil-Sen 
clear all
clc

diri = 'I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\';
prec = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'prec');

diri = 'I:\WORKS\30-Comp_EPHH\ERA5\t2w_2p5deg\';
lon  = ncread(strcat(diri, 'ERA5_t2wx_2p5deg.nc'), 'lon'); 
lat  = ncread(strcat(diri, 'ERA5_t2wx_2p5deg.nc'), 'lat');
t2wx = ncread(strcat(diri, 'ERA5_t2wx_2p5deg.nc'), 't2wx');

pts  = 95; %%%%
%--------------------------------------------------------------------------
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*44),[144 72 365 43]),3),4); % 1980.1.1-2022.12.31

prec_p = prctile(prec(:,:,365*1+1:365*44),pts,3);  % 1980.1.1-2022.12.31
t2wx_p = prctile(t2wx(:,:,365*1+1:365*44),pts,3);  % 1980.1.1-2022.12.31

prec_p = repmat(prec_p,[1 1 365*43+31]);
t2wx_p = repmat(t2wx_p,[1 1 365*43+31]);
%--------------------------------------------------------------------------
prec_event = prec(:,:,365*1-30:365*44)>=prec_p;       % 1979.12.1-2022.12.31
t2wx_event = t2wx(:,:,365*1+1:365*44+31)>=t2wx_p;     % 1980.1.1-2023.1.31
% sum(prec_event(:,:,32:365*43+31),3)
% sum(t2wx_event(:,:,1:365*43),3)

tau = 1;    %%%%
deltaT = 6; %%%%
Na   = round((100-pts)*0.01*365*43);
Nb   = round((100-pts)*0.01*365*43);

comp_pr = zeros(144,72,365*43);

for k = 1:365*43
for j = 1:length(lat)
    for i = 1:length(lon)
        if t2wx_event(i,j,k)==1&sum(prec_event(i,j,k+31-tau-deltaT:k+31-tau-1))>=1
           comp_pr(i,j,k) = 1;
        end
    end
end
disp(k)
end

comp_pr_sum = squeeze(sum(reshape(comp_pr,[144 72 365 43]),3));
%plot(1980:2020,squeeze(mean(mean(comp_pr_sum,1),2)),'r')

landsea = ncread('I:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');
landsea = reshape(landsea,[144*72 1]);

prec_clim = reshape(prec_clim,[144*72 1]);
%--------------------------------------------------------------------------
lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);
weight = cos(pi*lat1d/180.0);

lct    = find(landsea==1&prec_clim>100&((lat1d>60&lat1d<=90))); % high-latitude land area
weights = weight(lct)/mean(weight(lct));

comp_pr_sum = reshape(comp_pr_sum,[144*72 43]);

comp_pr_ann = mean(comp_pr_sum(lct,:).*repmat(weights,[1 43]),1);

%[b,a] = Theil_Sen_Regress([1980:2022]',comp_pr_ann')
%[H,p_value]=Mann_Kendall(comp_pr_ann',0.05)
% mean(comp_pr_ann(22:43))/mean(comp_pr_ann(1:22)) 
%**************************************************************************
myncid  = netcdf.create('figure_s5b.nc', 'NC_NOCLOBBER');
dimid1  = netcdf.defDim(myncid, 'year', 43);
varid1  = netcdf.defVar(myncid, 'comp_pr_ann', 'double', [dimid1]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, comp_pr_ann);
netcdf.close(myncid);


