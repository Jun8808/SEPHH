clear all
clc

lon = ncread('co2.nc','lon');
lat = ncread('co2.nc','lat');

co2 = ncread('co2.nc','co2');

co2_sum = sum(co2,3)/10^9;

co2_glb = squeeze(sum(sum(co2(:,:,:),1),2))/10^9;
co2_trp = squeeze(sum(sum(co2(:,25:48,:),1),2))/10^9;
co2_extrp = squeeze(sum(sum(co2(:,1:24,:),1),2))/10^9+squeeze(sum(sum(co2(:,49:72,:),1),2))/10^9;
%--------------------------------------------------------------------------
myncid  = netcdf.create('figure_s9.nc', 'NC_NOCLOBBER');
dimid1  = netcdf.defDim(myncid, 'lon', 144);
dimid2  = netcdf.defDim(myncid, 'lat', 72);
dimid3  = netcdf.defDim(myncid, 'year', 265);

varid1  = netcdf.defVar(myncid, 'lon', 'double', [dimid1]);
varid2  = netcdf.defVar(myncid, 'lat', 'double', [dimid2]);
varid3  = netcdf.defVar(myncid, 'co2_sum', 'double', [dimid1 dimid2]);
varid41  = netcdf.defVar(myncid, 'co2_glb', 'double', [dimid3]);
varid42  = netcdf.defVar(myncid, 'co2_trp', 'double', [dimid3]);
varid43  = netcdf.defVar(myncid, 'co2_extrp', 'double', [dimid3]);
netcdf.endDef(myncid);

netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, co2_sum);
netcdf.putVar(myncid, varid41, co2_glb);
netcdf.putVar(myncid, varid42, co2_trp);
netcdf.putVar(myncid, varid43, co2_extrp);
netcdf.close(myncid);

