clear all
clc

diri = 'H:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\';
prec = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*42),[144 72 365 41]),3),4); % 1980.1.1-2020.12.31

diri = 'H:\WORKS\30-Comp_EPHH\ERA5\Me_mon_2p5deg\';

lat = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lat');
lon = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lon');

Me  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Me');
Qh  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Qh');
Ql  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Ql');

Me  = reshape(Me,[size(Me,1) size(Me,2) 12 size(Me,3)/12]);
Qh  = reshape(Qh,[size(Qh,1) size(Qh,2) 12 size(Qh,3)/12]);
Ql  = reshape(Ql,[size(Ql,1) size(Ql,2) 12 size(Ql,3)/12]);

Me = squeeze(mean(Me(:,:,:,2:46),3))/1000; % KJ kg-1
Qh = squeeze(mean(Qh(:,:,:,2:46),3))/1000; % KJ kg-1
Ql = squeeze(mean(Ql(:,:,:,2:46),3))/1000; % KJ kg-1

years = 1980:2024;
years = years';

landsea = ncread('H:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');

for j = 1:size(Me,2)
    for i = 1:size(Me,1)

    if landsea(i,j)==1&prec_clim(i,j)>100&lat(j)>=-60
    [b,a] = Theil_Sen_Regress(years,squeeze(Me(i,j,1:45))');
    Me_trd(i,j)  = b*10;
    [b,a] = Theil_Sen_Regress(years,squeeze(Qh(i,j,1:45))');
    Qh_trd(i,j)  = b*10;
    [b,a] = Theil_Sen_Regress(years,squeeze(Ql(i,j,1:45))');
    Ql_trd(i,j)  = b*10;
    else
    Me_trd(i,j)  = -999;
    Qh_trd(i,j)  = -999;
    Ql_trd(i,j)  = -999;
    end

    end
    disp(j)
end
%--------------------------------------------------------------------------
Me_trd  = reshape(Me_trd,[size(Me_trd,1)*size(Me_trd,2) 1]);
Qh_trd  = reshape(Qh_trd,[size(Qh_trd,1)*size(Qh_trd,2) 1]);
Ql_trd  = reshape(Ql_trd,[size(Ql_trd,1)*size(Ql_trd,2) 1]);

diri     = 'H:\WORKS\30-Comp_EPHH\figure1\';
comp_pr_diff = ncread(strcat(diri,'fig1b.nc'),'comp_pr_diff_2d');
comp_pr_diff = reshape(comp_pr_diff, [size(comp_pr_diff,1)*size(comp_pr_diff,2) 1]);
%--------------------------------------------------------------------------
lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);

lct_trop   = find(lat1d(:)>=-30&lat1d(:)<=30&comp_pr_diff~=-999);
lct_extrop = find((lat1d(:)<-30|lat1d(:)>30)&comp_pr_diff~=-999);

Qh_trd_trop = Qh_trd(lct_trop);
Ql_trd_trop = Ql_trd(lct_trop);
Qh_trd_extrop = Qh_trd(lct_extrop);
Ql_trd_extrop = Ql_trd(lct_extrop);

comp_pr_diff_trop   = comp_pr_diff(lct_trop);
comp_pr_diff_extrop = comp_pr_diff(lct_extrop);

binT_trop = [-1.5:0.1:1.5];
binM_trop = [-1.5:0.1:1.5];
%lcts = 0;
comp_pr_diff_trop2d = zeros(length(binM_trop)-1,length(binT_trop)-1);

for i = 1:length(binM_trop)-1
   for j = 1:length(binT_trop)-1
   lct = find(Ql_trd_trop>=binM_trop(i)&Ql_trd_trop<binM_trop(i+1)&Qh_trd_trop>=binT_trop(j)&Qh_trd_trop<binT_trop(j+1)); 
   if length(lct)~=0
      comp_pr_diff_trop2d(i,j) = mean(comp_pr_diff_trop(lct));
   else
      comp_pr_diff_trop2d(i,j) = -999;
   end
   end
end

binT_extrop = [-1.5:0.1:1.5];
binM_extrop = [-1.5:0.1:1.5];
lcts = 0;
comp_pr_diff_extrop2d = zeros(length(binM_extrop)-1,length(binT_extrop)-1);

for i = 1:length(binM_extrop)-1
   for j = 1:length(binT_extrop)-1
   lct = find(Ql_trd_extrop>=binM_extrop(i)&Ql_trd_extrop<binM_extrop(i+1)&Qh_trd_extrop>=binT_extrop(j)&Qh_trd_extrop<binT_extrop(j+1)); 
   if length(lct)~=0
      comp_pr_diff_extrop2d(i,j) = mean(comp_pr_diff_extrop(lct));
   else
      comp_pr_diff_extrop2d(i,j) = -999;
   end
   lcts = lcts+length(lct);
   end
end
%--------------------------------------------------------------------------
myncid = netcdf.create('fig2c.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'binx',length(binM_trop));
dimid2 = netcdf.defDim(myncid,'biny',length(binT_trop));
dimid3 = netcdf.defDim(myncid,'gridx',length(binM_trop)-1);
dimid4 = netcdf.defDim(myncid,'gridy',length(binT_trop)-1);
varid11 = netcdf.defVar(myncid,'binM_trop','double',[dimid1]);
varid12 = netcdf.defVar(myncid,'binT_trop','double',[dimid2]);
varid13 = netcdf.defVar(myncid,'binM_extrop','double',[dimid1]);
varid14 = netcdf.defVar(myncid,'binT_extrop','double',[dimid2]);
varid21 = netcdf.defVar(myncid,'comp_pr_diff_trop2d','double',[dimid3 dimid4]);
varid22 = netcdf.defVar(myncid,'comp_pr_diff_extrop2d','double',[dimid3 dimid4]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid11, binM_trop);
netcdf.putVar(myncid, varid12, binT_trop);
netcdf.putVar(myncid, varid13, binM_extrop);
netcdf.putVar(myncid, varid14, binT_extrop);
netcdf.putVar(myncid, varid21, comp_pr_diff_trop2d);
netcdf.putVar(myncid, varid22, comp_pr_diff_extrop2d);
netcdf.close(myncid);
