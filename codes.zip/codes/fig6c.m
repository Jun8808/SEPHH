clear all
clc

lon  = [1.25:2.5:358.75]';
lat  = [-88.75:2.5:88.75]';

pop       = ncread('I:\WORKS\30-Comp_EPHH\figure5\pop.nc','pop');
mort_rate = ncread('I:\WORKS\30-Comp_EPHH\figure5\mort_rate.nc','mort_rate')/1000/365;
t2m_max   = ncread('I:\WORKS\30-Comp_EPHH\figure5\t2m_max.nc','t2m_max');

comp_pr_0 = ncread('I:\WORKS\30-Comp_EPHH\figure5\frequency_1980_1999.nc', 'comp_pr_sum_2d');
comp_pr_delta_adj = ncread('I:\WORKS\30-Comp_EPHH\figure4\fig4.nc', 'comp_pr_delta_adj');
comp_pr_delta_adj_p5 = ncread('I:\WORKS\30-Comp_EPHH\figure4\fig4.nc', 'comp_pr_delta_adj_p5');
comp_pr_delta_adj_p95 = ncread('I:\WORKS\30-Comp_EPHH\figure4\fig4.nc', 'comp_pr_delta_adj_p95');

for n = 1:11
comp_pr = comp_pr_0 + comp_pr_delta_adj(:,:,n);
comp_pr_p5 = comp_pr_0 + comp_pr_delta_adj_p5(:,:,n);
comp_pr_p95 = comp_pr_0 + comp_pr_delta_adj_p95(:,:,n);
comp_pr(find(comp_pr<0)) = NaN;
comp_pr_p5(find(comp_pr_p5<0)) = NaN;
comp_pr_p95(find(comp_pr_p95<0)) = NaN;

for j = 1:72
    for i = 1:144
        if t2m_max(i,j)>27.6
           Dhh_pr(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr(i,j)*(1.024-1);
           Dhh_pr_p5(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr_p5(i,j)*(1.024-1);
           Dhh_pr_p95(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr_p95(i,j)*(1.024-1);
        elseif t2m_max(i,j)>24.1&t2m_max(i,j)<=27.6
           Dhh_pr(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr(i,j)*(1.025-1);
           Dhh_pr_p5(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr_p5(i,j)*(1.025-1);
           Dhh_pr_p95(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr_p95(i,j)*(1.025-1);
        elseif t2m_max(i,j)>20.7&t2m_max(i,j)<=24.1
           Dhh_pr(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr(i,j)*(1.037-1);
           Dhh_pr_p5(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr_p5(i,j)*(1.037-1);
           Dhh_pr_p95(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr_p95(i,j)*(1.037-1);
        else
           Dhh_pr(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr(i,j)*(1.033-1);
           Dhh_pr_p5(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr_p5(i,j)*(1.033-1);
           Dhh_pr_p95(i,j,n) = pop(i,j,n)*mort_rate(i,j)*comp_pr_p95(i,j)*(1.033-1);
        end
    end
end
clear comp_pr

end

for n = 1:11
Dhh_pr_decade(n,1) = sum(sum(Dhh_pr(:,25:48,n),'omitnan'),'omitnan');
Dhh_pr_decade(n,2) = sum(sum(Dhh_pr(:,1:24,n),'omitnan'),'omitnan')+sum(sum(Dhh_pr(:,49:72,n),'omitnan'),'omitnan');
Dhh_pr_decade(n,3) = sum(sum(Dhh_pr(:,:,n),'omitnan'),'omitnan');

Dhh_pr_p5_decade(n,1) = sum(sum(Dhh_pr_p5(:,25:48,n),'omitnan'),'omitnan');
Dhh_pr_p5_decade(n,2) = sum(sum(Dhh_pr_p5(:,1:24,n),'omitnan'),'omitnan')+sum(sum(Dhh_pr_p5(:,49:72,n),'omitnan'),'omitnan');
Dhh_pr_p5_decade(n,3) = sum(sum(Dhh_pr_p5(:,:,n),'omitnan'),'omitnan');

Dhh_pr_p95_decade(n,1) = sum(sum(Dhh_pr_p95(:,25:48,n),'omitnan'),'omitnan');
Dhh_pr_p95_decade(n,2) = sum(sum(Dhh_pr_p95(:,1:24,n),'omitnan'),'omitnan')+sum(sum(Dhh_pr_p95(:,49:72,n),'omitnan'),'omitnan');
Dhh_pr_p95_decade(n,3) = sum(sum(Dhh_pr_p95(:,:,n),'omitnan'),'omitnan');
end
%**************************************************************************
myncid   = netcdf.create('fig5c.nc', 'NC_NOCLOBBER');
dimid1   = netcdf.defDim(myncid, 'decade', 11);
dimid2   = netcdf.defDim(myncid, 'reg', 3);
varid1   = netcdf.defVar(myncid, 'Dhh_pr_decade', 'double', [dimid1 dimid2]);
varid2   = netcdf.defVar(myncid, 'Dhh_pr_p5_decade', 'double', [dimid1 dimid2]);
varid3   = netcdf.defVar(myncid, 'Dhh_pr_p95_decade', 'double', [dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, Dhh_pr_decade);
netcdf.putVar(myncid, varid2, Dhh_pr_p5_decade);
netcdf.putVar(myncid, varid3, Dhh_pr_p95_decade);
netcdf.close(myncid);
