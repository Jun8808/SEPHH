clear all
clc

landsea = ncread('H:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');

prec = ncread('H:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\MSWEPv2_prec_2p5deg.nc', 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*42),[144 72 365 41]),3),4); % 1980.1.1-2020.12.31
clear prec
%--------------------------------------------------------------------------
diri = 'H:\WORKS\30-Comp_EPHH\ERA5\Me_mon_2p5deg\';
%ncdisp('ERA5_Me_2p5deg.nc')
lat = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lat');
lon = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lon');

Me_obs  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Me');
Me_obs  = reshape(Me_obs,[size(Me_obs,1) size(Me_obs,2) 12 size(Me_obs,3)/12]);
Me_obs  = squeeze(mean(Me_obs(:,:,:,2:46),3))/1000; % KJ kg-1
%--------------------------------------------------------------------------
Me_piCTL = ncread('piControl_me.nc', 'Me_piCTL');
Me_piCTL = Me_piCTL/1000; % KJ kg-1
%--------------------------------------------------------------------------
diri0    = 'H:\WORKS\30-Comp_EPHH\CMIP6\historical2\';
diri1    = 'H:\WORKS\30-Comp_EPHH\CMIP6\historical2_me\';

models   = {'ACCESS-CM2','ACCESS-ESM1-5','CanESM5','CMCC-ESM2','CNRM-CM6-1',...
            'CNRM-CM6-1-HR','CNRM-ESM2-1','EC-Earth3','EC-Earth3-CC','EC-Earth3-Veg',...
            'EC-Earth3-Veg-LR','FGOALS-g3','GFDL-CM4','GFDL-ESM4','HadGEM3-GC31-LL',...
            'HadGEM3-GC31-MM','INM-CM5-0','IPSL-CM6A-LR','KACE-1-0-G',...
            'MIROC6','MIROC-ES2L','MPI-ESM1-2-HR','MPI-ESM1-2-LR',...
            'MRI-ESM2-0','NorESM2-LM','NorESM2-MM','TaiESM1','UKESM1-0-LL'};

lon      = ncread(strcat(diri0, 'ACCESS-CM2_historical.nc'), 'lon'); 
lat      = ncread(strcat(diri0, 'ACCESS-CM2_historical.nc'), 'lat');

lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);

for m = 1:length(models)

fs0    = dir(strcat(diri0,models{m},'_historical.nc'));
fs1    = dir(strcat(diri1,models{m},'_historical.nc'));

f0     = strcat(diri0,fs0.name);
f1     = strcat(diri1,fs1.name);

comp_pr_ann(:,:,:,m)  = ncread(f0,'comp_pr_ann');
Me(:,:,:,m)           = ncread(f1,'Me')/1000;
disp(m)
end

comp_pr_delta_ori = squeeze(mean(comp_pr_ann(:,:,61:81,:),3)-mean(comp_pr_ann(:,:,1:21,:),3));
%**************************************************************************
landsea    = reshape(landsea,[144*72 1]);
prec_clim  = reshape(prec_clim,[144*72 1]);

Me_obs_glb     = reshape(Me_obs,[size(Me_obs,1)*size(Me_obs,2) size(Me_obs,3)]);
Me_piCTL_glb   = reshape(Me_piCTL,[size(Me_piCTL,1)*size(Me_piCTL,2) size(Me_piCTL,3) size(Me_piCTL,4)]);
Me_glb         = reshape(Me,[size(Me,1)*size(Me,2) size(Me,3) size(Me,4)]);

lct    = find(landsea==1&prec_clim>100&lat1d>=-60);
weight = cos(pi*lat1d(lct)/180.0);
weight = weight/mean(weight);

Me_obs_glb       = mean(Me_obs_glb(lct,:).*repmat(weight,[1 45]),1);
Me_piCTL_glb     = squeeze(mean(Me_piCTL_glb(lct,:,:).*repmat(weight,[1 50 180]),1));
Me_glb           = squeeze(mean(Me_glb(lct,:,:).*repmat(weight,[1 121 28]),1));

b = polyfit(1980:2024,Me_obs_glb,1);
Me_obs_glb_trd   = b(1)*10;

for k = 1:180
    b = polyfit(1980:2024,squeeze(Me_piCTL_glb(1:45,k)),1);
    Me_piCTL_glb_trd(k) = b(1)*10;
    clear b
end

for k = 1:28
    b = polyfit(1980:2024,squeeze(Me_glb(1:45,k)),1);
    Me_glb_trd(k) = b(1)*10;
    clear b
end
%**************************************************************************
for j = 1:72
    for i = 1:144
    [r,p] = corrcoef(Me_glb_trd,squeeze(comp_pr_delta_ori(i,j,:)));

    mean_z = mean(comp_pr_delta_ori(i,j,:));
    std_z  = std(comp_pr_delta_ori(i,j,:));

    mean_x = mean(Me_glb_trd);
    std_x  = std(Me_glb_trd);

    mean_y = Me_obs_glb_trd;
    std_y  = std(Me_piCTL_glb_trd);

    comp_pr_delta_adj(i,j) = mean_z+r(1,2)*std_z*std_x*(mean_y-mean_x)/(std_x^2+std_y^2);

    clear r p mean_z std_z mean_x std_x mean_y std_y
    end
    disp(j)
end
comp_pr_delta_adj(find(landsea==0|prec_clim<=100|lat1d<-60)) = -999;
% mean(comp_pr_delta_adj(lct).*weight,1)

% x = comp_pr_delta_adj;
% lct = find(x~=-999);
% mean(x(lct))
%**************************************************************************
myncid  = netcdf.create('fig4d.nc', 'NC_NOCLOBBER');
dimid1  = netcdf.defDim(myncid, 'lon', 144);
dimid2  = netcdf.defDim(myncid, 'lat', 72);

varid1  = netcdf.defVar(myncid, 'lon', 'double', [dimid1]);
varid2  = netcdf.defVar(myncid, 'lat', 'double', [dimid2]);
varid3  = netcdf.defVar(myncid, 'comp_pr_delta_adj', 'double', [dimid1 dimid2]);
netcdf.endDef(myncid);

netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, comp_pr_delta_adj);
netcdf.close(myncid);
