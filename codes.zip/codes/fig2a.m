clear all
clc

diri = 'H:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\';
prec = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*42),[144 72 365 41]),3),4); % 1980.1.1-2020.12.31

diri = 'H:\WORKS\30-Comp_EPHH\ERA5\Me_mon_2p5deg\';
%ncdisp('ERA5_Me_mon_2p5deg.nc')
lat = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lat');
lon = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lon');

Me  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Me');
Qh  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Qh');
Ql  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Ql');

Me  = reshape(Me,[size(Me,1) size(Me,2) 12 size(Me,3)/12]);
Qh  = reshape(Qh,[size(Qh,1) size(Qh,2) 12 size(Qh,3)/12]);
Ql  = reshape(Ql,[size(Ql,1) size(Ql,2) 12 size(Ql,3)/12]);

Me = squeeze(mean(Me(:,:,:,2:46),3))/1000; % KJ kg-1
Qh = squeeze(mean(Qh(:,:,:,2:46),3))/1000; % KJ kg-1
Ql = squeeze(mean(Ql(:,:,:,2:46),3))/1000; % KJ kg-1

years  = 1980:2024;
years  = years';

landsea = ncread('H:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');

for j = 1:size(Me,2)
    for i = 1:size(Me,1)
    
    if landsea(i,j)==1&prec_clim(i,j)>100&lat(j)>=-60
    [b,a]           = Theil_Sen_Regress(years,squeeze(Me(i,j,1:45))');
    Me_trd(i,j)     = b*10;
    [H,p_value]     = Mann_Kendall(squeeze(Me(i,j,1:45))',0.01);
    Me_sig_trd(i,j) = H;

    [b,a]           = Theil_Sen_Regress(years,squeeze(Qh(i,j,1:45))');
    Qh_trd(i,j)     = b*10;
    [H,p_value]     = Mann_Kendall(squeeze(Qh(i,j,1:45))',0.01);
    Qh_sig_trd(i,j) = H;

    [b,a]           = Theil_Sen_Regress(years,squeeze(Ql(i,j,1:45))');
    Ql_trd(i,j)     = b*10;
    [H,p_value]     = Mann_Kendall(squeeze(Ql(i,j,1:45))',0.01);
    Ql_sig_trd(i,j) = H;

    else
    Me_trd(i,j)     = -999;
    Me_sig_trd(i,j) = -999;
    Qh_trd(i,j)     = -999;
    Qh_sig_trd(i,j) = -999;
    Ql_trd(i,j)     = -999;
    Ql_sig_trd(i,j) = -999;    
    end
    end

    disp(j)
end

lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);

Me_sig_trd_1d = reshape(Me_sig_trd,[144*72 1]);
Qh_sig_trd_1d = reshape(Qh_sig_trd,[144*72 1]);
Ql_sig_trd_1d = reshape(Ql_sig_trd,[144*72 1]);

lonsig_Me = lon1d(find(Me_sig_trd_1d==1));
latsig_Me = lat1d(find(Me_sig_trd_1d==1));
lonsig_Qh = lon1d(find(Qh_sig_trd_1d==1));
latsig_Qh = lat1d(find(Qh_sig_trd_1d==1));
lonsig_Ql = lon1d(find(Ql_sig_trd_1d==1));
latsig_Ql = lat1d(find(Ql_sig_trd_1d==1));
%weights = cos(lat.*pi./180.0);
%weights = weights/mean(weights);
%weights = repmat(weights',[144 1 45]);

%Me_y = squeeze(mean(mean(Me(:,:,1:45).*weights,1),2))-273.15;
%Me_y = Me_y-mean(Me_y(1:45));
%[b,a] = Theil_Sen_Regress(years,Me_y);
%b*45

for i = 1:length(lat)
lct = find(Me_trd(:,i)~=-999);
if length(lct)~=0
Me_trd_lat(i) = mean(Me_trd(lct,i),1);
else
Me_trd_lat(i) = -999;
end

lct = find(Qh_trd(:,i)~=-999);
if length(lct)~=0
Qh_trd_lat(i) = mean(Qh_trd(lct,i),1);
else
Qh_trd_lat(i) = -999;
end

lct = find(Ql_trd(:,i)~=-999);
if length(lct)~=0
Ql_trd_lat(i) = mean(Ql_trd(lct,i),1);
else
Ql_trd_lat(i) = -999;
end
end
%--------------------------------------------------------------------------
myncid = netcdf.create('fig2a.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'lat',length(lat));
dimid2 = netcdf.defDim(myncid,'lon',length(lon));
dimid3_Me_sig = netcdf.defDim(myncid,'Me_sig',length(lonsig_Me));
dimid3_Qh_sig = netcdf.defDim(myncid,'Qh_sig',length(lonsig_Qh));
dimid3_Ql_sig = netcdf.defDim(myncid,'Ql_sig',length(lonsig_Ql));

varid01 = netcdf.defVar(myncid,'lat','double',[dimid1]);
varid02 = netcdf.defVar(myncid,'lon','double',[dimid2]);

varid1 = netcdf.defVar(myncid,'Me_trd','double',[dimid2 dimid1]);
varid2 = netcdf.defVar(myncid,'Qh_trd','double',[dimid2 dimid1]);
varid3 = netcdf.defVar(myncid,'Ql_trd','double',[dimid2 dimid1]);

varid11 = netcdf.defVar(myncid,'lonsig_Me','double',[dimid3_Me_sig]);
varid12 = netcdf.defVar(myncid,'latsig_Me','double',[dimid3_Me_sig]);
varid21 = netcdf.defVar(myncid,'lonsig_Qh','double',[dimid3_Qh_sig]);
varid22 = netcdf.defVar(myncid,'latsig_Qh','double',[dimid3_Qh_sig]);
varid31 = netcdf.defVar(myncid,'lonsig_Ql','double',[dimid3_Ql_sig]);
varid32 = netcdf.defVar(myncid,'latsig_Ql','double',[dimid3_Ql_sig]);

varid4 = netcdf.defVar(myncid,'Me_trd_lat','double',[dimid1]);
varid5 = netcdf.defVar(myncid,'Qh_trd_lat','double',[dimid1]);
varid6 = netcdf.defVar(myncid,'Ql_trd_lat','double',[dimid1]);

netcdf.endDef(myncid);
netcdf.putVar(myncid, varid01, lat);
netcdf.putVar(myncid, varid02, lon);
netcdf.putVar(myncid, varid1, Me_trd);
netcdf.putVar(myncid, varid2, Qh_trd);
netcdf.putVar(myncid, varid3, Ql_trd);

netcdf.putVar(myncid, varid11, double(lonsig_Me));
netcdf.putVar(myncid, varid12, double(latsig_Me));
netcdf.putVar(myncid, varid21, double(lonsig_Qh));
netcdf.putVar(myncid, varid22, double(latsig_Qh));
netcdf.putVar(myncid, varid31, double(lonsig_Ql));
netcdf.putVar(myncid, varid32, double(latsig_Ql));

netcdf.putVar(myncid, varid4, Me_trd_lat);
netcdf.putVar(myncid, varid5, Qh_trd_lat);
netcdf.putVar(myncid, varid6, Ql_trd_lat);

netcdf.reDef(myncid);
netcdf.putAtt(myncid, varid01,'units','degrees_north');
netcdf.putAtt(myncid, varid02,'units','degrees_east');
netcdf.close(myncid);
