clear all
clc

comp_pr     = ncread('I:\WORKS\30-Comp_EPHH\figure1\fig1a.nc','comp_pr_sum_2d');
prec_diff   = ncread('I:\WORKS\30-Comp_EPHH\figure_s3\figure_s3a.nc','prec_diff');

comp_pr     = reshape(comp_pr,[size(comp_pr,1)*size(comp_pr,2) 1]);
prec_diff   = reshape(prec_diff,[size(prec_diff,1)*size(prec_diff,2) 1]);

bins = [-6:1:12];

for i = 1:length(bins)+1

if i==1
lct = find(prec_diff<bins(i)&comp_pr~=-999);
comp_pr_bins(i) = mean(comp_pr(lct));
elseif i==length(bins)+1
lct = find(prec_diff>=bins(i-1)&comp_pr~=-999);
comp_pr_bins(i) = mean(comp_pr(lct));
else
lct = find(prec_diff>=bins(i-1)&prec_diff<bins(i)&comp_pr~=-999);
comp_pr_bins(i) = mean(comp_pr(lct));
end

clear lct

end
%**************************************************************************
myncid  = netcdf.create('figure_s3b.nc', 'NC_NOCLOBBER');
dimid1  = netcdf.defDim(myncid, 'bins', length(bins)+1);
varid0  = netcdf.defVar(myncid, 'bins_center', 'double', [dimid1]);
varid1  = netcdf.defVar(myncid, 'comp_pr_bins', 'double', [dimid1]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid0, [-6.5:1:12.5]);
netcdf.putVar(myncid, varid1, comp_pr_bins);
netcdf.close(myncid);




