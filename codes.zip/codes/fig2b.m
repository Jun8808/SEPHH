clear all
clc

diri = 'I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\';
prec = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*44),[144 72 365 43]),3),4); % 1980.1.1-2022.12.31

diri = 'I:\WORKS\30-Comp_EPHH\ERA5\Me_mon_2p5deg\';
%ncdisp('ERA5_Me_mon_2p5deg.nc')
lat = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lat');
lon = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lon');

Me  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Me');
Me  = reshape(Me,[size(Me,1) size(Me,2) 12 size(Me,3)/12]);

% mons = [31 28 31 30 31 30 31 31 30 31 30 31];
% 
% Me_mon = zeros([length(lon) length(lat) 12 44]);
% Qh_mon = zeros([length(lon) length(lat) 12 44]);
% Ql_mon = zeros([length(lon) length(lat) 12 44]);
% 
% days = 0;
% 
% for m = 1:12
% Me_mon(:,:,m,:) = mean(Me(:,:,days+1:days+mons(m),:),3);
% Qh_mon(:,:,m,:) = mean(Qh(:,:,days+1:days+mons(m),:),3);
% Ql_mon(:,:,m,:) = mean(Ql(:,:,days+1:days+mons(m),:),3);
% 
% days = days+mons(m);
% end
% clear Me Qh Ql

Me = squeeze(mean(Me(:,:,:,2:44),3))/1000; % KJ kg-1

years = 1980:2022;
years = years';

landsea = ncread('I:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');

for j = 1:size(Me,2)
    for i = 1:size(Me,1)

    if landsea(i,j)==1&prec_clim(i,j)>100&lat(j)>=-60
    [b,a] = Theil_Sen_Regress(years,squeeze(Me(i,j,1:43))');
    Me_trd(i,j)  = b*10;
    else
    Me_trd(i,j)  = -999;
    end

    end
    disp(j)
end
%--------------------------------------------------------------------------
Me_trd  = reshape(Me_trd,[size(Me_trd,1)*size(Me_trd,2) 1]);

diri     = 'I:\WORKS\30-Comp_EPHH\figure1\';
comp_pr_diff = ncread(strcat(diri,'fig1b.nc'),'comp_pr_diff_2d');
comp_pr_diff = reshape(comp_pr_diff, [size(comp_pr_diff,1)*size(comp_pr_diff,2) 1]);
%--------------------------------------------------------------------------
lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);

lct_trop   = find(lat1d(:)>=-30&lat1d(:)<=30&comp_pr_diff~=-999);
lct_extrop = find((lat1d(:)<-30|lat1d(:)>30)&lat1d(:)>=-60&comp_pr_diff~=-999);

Me_trd_trop   = Me_trd(lct_trop);
Me_trd_extrop = Me_trd(lct_extrop);

comp_pr_diff_trop   = comp_pr_diff(lct_trop);
comp_pr_diff_extrop = comp_pr_diff(lct_extrop);

%plot(Me_trd_trop,comp_pr_diff_trop,'o')
%[b,a] = Theil_Sen_Regress(Me_trd_trop,comp_pr_diff_trop)
%[r,p] = corrcoef(Me_trd_trop,comp_pr_diff_trop)

%plot(Me_trd_extrop,comp_pr_diff_extrop,'o')
%[b,a] = Theil_Sen_Regress(Me_trd_extrop,comp_pr_diff_extrop)
%[r,p] =  corrcoef(Me_trd_extrop,comp_pr_diff_extrop)
%--------------------------------------------------------------------------
myncid = netcdf.create('fig2b.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'trop',length(Me_trd_trop));
dimid2 = netcdf.defDim(myncid,'extrop',length(Me_trd_extrop));
varid11 = netcdf.defVar(myncid,'Me_trd_trop','double',[dimid1]);
varid12 = netcdf.defVar(myncid,'Me_trd_extrop','double',[dimid2]);
varid21 = netcdf.defVar(myncid,'comp_pr_diff_trop','double',[dimid1]);
varid22 = netcdf.defVar(myncid,'comp_pr_diff_extrop','double',[dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid11, Me_trd_trop);
netcdf.putVar(myncid, varid12, Me_trd_extrop);
netcdf.putVar(myncid, varid21, comp_pr_diff_trop);
netcdf.putVar(myncid, varid22, comp_pr_diff_extrop);
netcdf.close(myncid);
