% 2.5 deg, 1981-2020, Theil-Sen 
clear all
clc

diri = 'I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\';

lat = ncread(strcat(diri,'MSWEPv2_prec_2p5deg.nc'),'lat');
lon = ncread(strcat(diri,'MSWEPv2_prec_2p5deg.nc'),'lon');
prec = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'prec');

prec = reshape(prec,[size(prec,1) size(prec,2) 365 size(prec,3)/365]);
prec = mean(prec(:,:,:,2:44),4); % 1980-2022

for j = 1:length(lat)
    for i = 1:length(lon)
        if lat(j)>0
           prec_diff(i,j)  = mean(prec(i,j,121:273),3) - mean(cat(3,prec(i,j,1:90),prec(i,j,305:365)),3);
           prec_ratio(i,j) = sum(prec(i,j,121:273),3)/sum(prec(i,j,:),3);
        else
           prec_diff(i,j)  = mean(cat(3,prec(i,j,1:90),prec(i,j,305:365)),3) - mean(prec(i,j,121:273),3);
           prec_ratio(i,j) = sum(cat(3,prec(i,j,1:90),prec(i,j,305:365)),3)/sum(prec(i,j,:),3);
        end

    end
end

% for j = 1:length(lat)
%     for i = 1:length(lon)
%     if prec_ratio(i,j)<0.55
%     prec_diff(i,j) = -999;
%     end
%     end
% end
%**************************************************************************
myncid  = netcdf.create('figure_s3a.nc', 'NC_NOCLOBBER');
dimid1  = netcdf.defDim(myncid, 'lon', 144);
dimid2  = netcdf.defDim(myncid, 'lat', 72);

varid1  = netcdf.defVar(myncid, 'lon', 'double', [dimid1]);
varid2  = netcdf.defVar(myncid, 'lat', 'double', [dimid2]);
varid3  = netcdf.defVar(myncid, 'prec_diff', 'double', [dimid1 dimid2]);
varid4  = netcdf.defVar(myncid, 'prec_ratio', 'double', [dimid1 dimid2]);
netcdf.endDef(myncid);

netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, prec_diff);
netcdf.putVar(myncid, varid4, prec_ratio);
netcdf.close(myncid);


