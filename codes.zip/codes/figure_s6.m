% 2.5 deg, 1981-2020, Theil-Sen 
clear all
clc

diri = 'I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\';
prec = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'prec');

diri = 'I:\WORKS\30-Comp_EPHH\ERA5\t2w_2p5deg\';
lon  = ncread(strcat(diri, 'ERA5_t2wx_2p5deg.nc'), 'lon'); 
lat  = ncread(strcat(diri, 'ERA5_t2wx_2p5deg.nc'), 'lat');
t2wx = ncread(strcat(diri, 'ERA5_t2wx_2p5deg.nc'), 't2wx');

pts  = 95; %%%%
%--------------------------------------------------------------------------
prec_clim_mean = mean(sum(reshape(prec(:,:,365*1+1:365*44),[144 72 365 43]),3),4); % 1980.1.1-2022.12.31

prec_p = prctile(prec(:,:,365*1+1:365*44),pts,3);  % 1980.1.1-2022.12.31
t2wx_p = prctile(t2wx(:,:,365*1+1:365*44),pts,3);  % 1980.1.1-2022.12.31

prec_p = repmat(prec_p,[1 1 365*43+31]);
t2wx_p = repmat(t2wx_p,[1 1 365*43+31]);
%--------------------------------------------------------------------------
prec_event = prec(:,:,365*1-30:365*44)>=prec_p;       % 1979.12.1-2022.12.31
t2wx_event = t2wx(:,:,365*1+1:365*44+31)>=t2wx_p;     % 1980.1.1-2023.1.31
% sum(prec_event(:,:,32:365*43+31),3)
% sum(t2wx_event(:,:,1:365*43),3)

tau = 1;    %%%%
deltaT = 6; %%%%
Na   = round((100-pts)*0.01*365*43);
Nb   = round((100-pts)*0.01*365*43);

comp_pr = zeros(144,72,365*43);

for k = 1:365*43
for j = 1:length(lat)
    for i = 1:length(lon)
        if t2wx_event(i,j,k)==1&sum(prec_event(i,j,k+31-tau-deltaT:k+31-tau-1))>=1
           comp_pr(i,j,k) = 1;
        end
    end
end
disp(k)
end

landsea = ncread('I:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');

clear prec prec_event prec_p t2wx t2wx_event t2wx_p
%**************************************************************************
%sum(sum(sum(prec_event-prec_t2wx_event-prec_not2wx_event)))
diri = 'I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\'; 
prec = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'prec'); % 1979.1-2022.12

diri = 'I:\WORKS\30-Comp_EPHH\ERA5\t2w_2p5deg\';
t2wx = ncread(strcat(diri, 'ERA5_t2wx_2p5deg.nc'), 't2wx');    % 1979.1-2023.01

diri = 'I:\WORKS\30-Comp_EPHH\ERA5\t2m_2p5deg\';
t2m  = ncread(strcat(diri, 'ERA5_t2m_2p5deg.nc'), 't2m');      % 1979.1-2023.01

diri = 'I:\WORKS\30-Comp_EPHH\ERA5\rh2_2p5deg\';
rh2  = ncread(strcat(diri, 'ERA5_rh2_2p5deg.nc'), 'rh2');   % 1979.1-2023.01
%--------------------------------------------------------------------------
smd = 31;

prec_clim0 = squeeze(mean(reshape(prec(:,:,365*1+1:365*44),[size(prec,1) size(prec,2) 365 43]),4));
prec_clim = smoothdata(prec_clim0,3,"gaussian",smd);

prec_clim = reshape(repmat(prec_clim,[1 1 1 43]),[size(prec,1) size(prec,2) 365*43]);

prec_clim2(:,:,1:31)                = prec_clim(:,:,335:365);
prec_clim2(:,:,32:365*43+31)        = prec_clim(:,:,:);
prec_clim2(:,:,365*43+32:365*43+62) = prec_clim(:,:,1:31);

prec_clim = prec_clim2;
clear prec_clim0 prec_clim2
%--------------------------------------------------------------------------
t2wx_clim0 = squeeze(mean(reshape(t2wx(:,:,365*1+1:365*44),[size(t2wx,1) size(t2wx,2) 365 43]),4));
t2wx_clim = smoothdata(t2wx_clim0,3,"gaussian",smd);

t2wx_clim = reshape(repmat(t2wx_clim,[1 1 1 43]),[size(t2wx,1) size(t2wx,2) 365*43]);

t2wx_clim2(:,:,1:31)                = t2wx_clim(:,:,335:365);
t2wx_clim2(:,:,32:365*43+31)        = t2wx_clim(:,:,:);
t2wx_clim2(:,:,365*43+32:365*43+62) = t2wx_clim(:,:,1:31);

t2wx_clim = t2wx_clim2;
clear t2wx_clim0 t2wx_clim2
%--------------------------------------------------------------------------
t2m_clim0 = squeeze(mean(reshape(t2m(:,:,365*1+1:365*44),[size(t2m,1) size(t2m,2) 365 43]),4));
t2m_clim  = smoothdata(t2m_clim0,3,"gaussian",smd);

t2m_clim = reshape(repmat(t2m_clim,[1 1 1 43]),[size(t2m,1) size(t2m,2) 365*43]);

t2m_clim2(:,:,1:31)                = t2m_clim(:,:,335:365);
t2m_clim2(:,:,32:365*43+31)        = t2m_clim(:,:,:);
t2m_clim2(:,:,365*43+32:365*43+62) = t2m_clim(:,:,1:31);

t2m_clim = t2m_clim2;
clear t2m_clim0 t2m_clim2
%--------------------------------------------------------------------------
rh2_clim0 = squeeze(mean(reshape(rh2(:,:,365*1+1:365*44),[size(rh2,1) size(rh2,2) 365 43]),4));
rh2_clim  = smoothdata(rh2_clim0,3,"gaussian",smd);

rh2_clim = reshape(repmat(rh2_clim,[1 1 1 43]),[size(rh2,1) size(rh2,2) 365*43]);

rh2_clim2(:,:,1:31)                = rh2_clim(:,:,335:365);
rh2_clim2(:,:,32:365*43+31)        = rh2_clim(:,:,:);
rh2_clim2(:,:,365*43+32:365*43+62) = rh2_clim(:,:,1:31);

rh2_clim = rh2_clim2;
clear rh2_clim0 rh2_clim2
%--------------------------------------------------------------------------
prec(:,:,44*365+1:44*365+31) = prec(:,:,43*365+1:43*365+31);

prec_ano  = prec(:,:,365*1-30:365*44+31)-prec_clim;
t2wx_ano  = t2wx(:,:,365*1-30:365*44+31)-t2wx_clim;
t2m_ano   = t2m(:,:,365*1-30:365*44+31)-t2m_clim;
rh2_ano   = rh2(:,:,365*1-30:365*44+31)-rh2_clim;
%**************************************************************************
for j = 1:size(prec,2)
    for i = 1:size(prec,1)
     comp_pr0 = squeeze(comp_pr(i,j,:));
     lct = find(comp_pr0==1);
    
       for k = 1:length(lct)
         prec_lct(:,k)  = squeeze(prec_ano(i,j,lct(k)+31-7:lct(k)+31+7));
         t2wx_lct(:,k)  = squeeze(t2wx_ano(i,j,lct(k)+31-7:lct(k)+31+7));
         t2m_lct(:,k)   = squeeze(t2m_ano(i,j,lct(k)+31-7:lct(k)+31+7));
         rh2_lct(:,k)   = squeeze(rh2_ano(i,j,lct(k)+31-7:lct(k)+31+7));
       end

      prec_comp(i,j,:)  = mean(prec_lct,2);
      t2wx_comp(i,j,:)  = mean(t2wx_lct,2); 
      t2m_comp(i,j,:)   = mean(t2m_lct,2); 
      rh2_comp(i,j,:)   = mean(rh2_lct,2); 
    end
disp(j)
end

latc = repmat(lat',[length(lon) 1]);
lonc = repmat(lon',[length(lat) 1])';

prec_comp  = reshape(prec_comp,[size(prec_comp,1)*size(prec_comp,2) size(prec_comp,3)]);
t2wx_comp  = reshape(t2wx_comp,[size(t2wx_comp,1)*size(t2wx_comp,2) size(t2wx_comp,3)]);
t2m_comp   = reshape(t2m_comp,[size(t2m_comp,1)*size(t2m_comp,2) size(t2m_comp,3)]);
rh2_comp   = reshape(rh2_comp,[size(rh2_comp,1)*size(rh2_comp,2) size(rh2_comp,3)]);

prec_comp_trop  = mean(prec_comp(find(latc(:)<=30&latc(:)>=-30&landsea(:)==1&prec_clim_mean(:)>100),:),1);
t2wx_comp_trop  = mean(t2wx_comp(find(latc(:)<=30&latc(:)>=-30&landsea(:)==1&prec_clim_mean(:)>100),:),1);
t2m_comp_trop   = mean(t2m_comp(find(latc(:)<=30&latc(:)>=-30&landsea(:)==1&prec_clim_mean(:)>100),:),1);
rh2_comp_trop   = mean(rh2_comp(find(latc(:)<=30&latc(:)>=-30&landsea(:)==1&prec_clim_mean(:)>100),:),1);

prec_comp_extrop    = mean(prec_comp(find((latc(:)<-30|latc(:)>30)&latc(:)>=-60&landsea(:)==1&prec_clim_mean(:)>100),:),1);
t2wx_comp_extrop    = mean(t2wx_comp(find((latc(:)<-30|latc(:)>30)&latc(:)>=-60&landsea(:)==1&prec_clim_mean(:)>100),:),1);
t2m_comp_extrop     = mean(t2m_comp(find((latc(:)<-30|latc(:)>30)&latc(:)>=-60&landsea(:)==1&prec_clim_mean(:)>100),:),1);
rh2_comp_extrop     = mean(rh2_comp(find((latc(:)<-30|latc(:)>30)&latc(:)>=-60&landsea(:)==1&prec_clim_mean(:)>100),:),1);
%--------------------------------------------------------------------------
myncid = netcdf.create('figure_s6.nc', 'NC_NOCLOBBER');
dimid  = netcdf.defDim(myncid, 'day', 15);
varid01 = netcdf.defVar(myncid, 'prec_comp_trop', 'float', [dimid]);
varid02 = netcdf.defVar(myncid, 't2wx_comp_trop', 'float', [dimid]);
varid03 = netcdf.defVar(myncid, 't2m_comp_trop', 'float', [dimid]);
varid04 = netcdf.defVar(myncid, 'rh2_comp_trop', 'float', [dimid]);
varid11 = netcdf.defVar(myncid, 'prec_comp_extrop', 'float', [dimid]);
varid12 = netcdf.defVar(myncid, 't2wx_comp_extrop', 'float', [dimid]);
varid13 = netcdf.defVar(myncid, 't2m_comp_extrop', 'float', [dimid]);
varid14 = netcdf.defVar(myncid, 'rh2_comp_extrop', 'float', [dimid]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid01, prec_comp_trop);
netcdf.putVar(myncid, varid02, t2wx_comp_trop);
netcdf.putVar(myncid, varid03, t2m_comp_trop);
netcdf.putVar(myncid, varid04, rh2_comp_trop);
netcdf.putVar(myncid, varid11, prec_comp_extrop);
netcdf.putVar(myncid, varid12, t2wx_comp_extrop);
netcdf.putVar(myncid, varid13, t2m_comp_extrop);
netcdf.putVar(myncid, varid14, rh2_comp_extrop);
netcdf.close(myncid);