clear all
clc

lon  = [1.25:2.5:358.75]';
lat  = [-88.75:2.5:88.75]';

pop       = ncread('H:\WORKS\30-Comp_EPHH\figure5\pop.nc','pop');
mort_rate = ncread('H:\WORKS\30-Comp_EPHH\figure5\mort_rate.nc','mort_rate')/1000/365;
t2m_max   = ncread('H:\WORKS\30-Comp_EPHH\figure5\t2m_max.nc','t2m_max');

comp_pr_0 = ncread('H:\WORKS\30-Comp_EPHH\figure5\frequency_1980_2000.nc', 'comp_pr_sum_2d');
comp_pr_0(find(comp_pr_0<0)) = NaN;

for j = 1:72
    for i = 1:144
        if t2m_max(i,j)>27.6
           Dhh_pr(i,j) = pop(i,j,1)*mort_rate(i,j)*comp_pr_0(i,j)*(1.024-1);
        elseif t2m_max(i,j)>24.1&t2m_max(i,j)<=27.6
           Dhh_pr(i,j) = pop(i,j,1)*mort_rate(i,j)*comp_pr_0(i,j)*(1.025-1);
        elseif t2m_max(i,j)>20.7&t2m_max(i,j)<=24.1
           Dhh_pr(i,j) = pop(i,j,1)*mort_rate(i,j)*comp_pr_0(i,j)*(1.037-1);
        else
           Dhh_pr(i,j) = pop(i,j,1)*mort_rate(i,j)*comp_pr_0(i,j)*(1.033-1);
        end
    end
end

%sum(sum(pop,'omitnan'))
%sum(sum(Dhh_pr,'omitnan'))
%sum(sum(Dhh_tr,'omitnan'))

Dhh_pr(find(isnan(Dhh_pr)==1))=-999;
%**************************************************************************
myncid   = netcdf.create('fig5a.nc', 'NC_NOCLOBBER');
dimid1   = netcdf.defDim(myncid, 'lon', 144);
dimid2   = netcdf.defDim(myncid, 'lat', 72);
varid1   = netcdf.defVar(myncid, 'lon', 'double', [dimid1]);
varid2   = netcdf.defVar(myncid, 'lat', 'double', [dimid2]);
varid3   = netcdf.defVar(myncid, 'Dhh_pr', 'double', [dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, Dhh_pr);
netcdf.close(myncid);
