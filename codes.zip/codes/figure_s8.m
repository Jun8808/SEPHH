clear all
clc

diri0    = 'I:\WORKS\30-Comp_EPHH\CMIP6\historical2\';
diri1    = 'I:\WORKS\30-Comp_EPHH\CMIP6\historical2_me\';

models   = {'ACCESS-CM2','ACCESS-ESM1-5','CanESM5','CMCC-ESM2','CNRM-CM6-1',...
            'CNRM-CM6-1-HR','CNRM-ESM2-1','EC-Earth3','EC-Earth3-CC','EC-Earth3-Veg',...
            'EC-Earth3-Veg-LR','FGOALS-g3','GFDL-CM4','GFDL-ESM4','HadGEM3-GC31-LL',...
            'HadGEM3-GC31-MM','INM-CM5-0','IPSL-CM6A-LR','KACE-1-0-G',...
            'MIROC6','MIROC-ES2L','MPI-ESM1-2-HR','MPI-ESM1-2-LR',...
            'MRI-ESM2-0','NorESM2-LM','NorESM2-MM','TaiESM1','UKESM1-0-LL'};

lon      = ncread(strcat(diri0, 'ACCESS-CM2_historical.nc'), 'lon'); 
lat      = ncread(strcat(diri0, 'ACCESS-CM2_historical.nc'), 'lat');
lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);

landsea = ncread('I:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');

prec = ncread('I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\MSWEPv2_prec_2p5deg.nc', 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*44),[144 72 365 43]),3),4); % 1980.1.1-2022.12.31
%--------------------------------------------------------------------------
diri = 'I:\WORKS\30-Comp_EPHH\ERA5\Me_mon_2p5deg\';
%ncdisp('ERA5_Me_2p5deg.nc')
lat = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lat');
lon = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'lon');

Me  = ncread(strcat(diri,'ERA5_Me_mon_2p5deg.nc'),'Me');
Me_mon  = reshape(Me,[size(Me,1) size(Me,2) 12 size(Me,3)/12]);
Me = squeeze(mean(Me_mon(:,:,:,2:44),3))/1000; % KJ kg-1

clear Me_mon
%--------------------------------------------------------------------------
for j = 1:72
    for i = 1:144
    b = polyfit(1980:2022,squeeze(Me(i,j,:)),1);
    Me_obs_trd(i,j) = b(1)*10;
    clear b
    end
end

clear Me

for m = 1:length(models)
fs1    = dir(strcat(diri1,models{m},'_historical.nc'));
f1     = strcat(diri1,fs1.name);
Me(:,:,:,m)     = ncread(f1,'Me')/1000;
disp(m)
end

for m = 1:28
for j = 1:72
    for i = 1:144
        b = polyfit(1980:2022,squeeze(Me(i,j,1:43,m)),1);
        Me_mod_trd(i,j,m) = b(1)*10;
        clear b
    end
end
disp(m)
end

Me_mod_trd = mean(Me_mod_trd,3);

% plot(Me_mod_trd,Me_obs_trd,'o')
% xlim([-1,2])
% ylim([-1,2])

Me_trd_diff =  Me_mod_trd- Me_obs_trd;

Me_trd_diff(find((landsea~=1|prec_clim<=100)|isnan(Me_trd_diff)==1|lat1d<-60) = -999;
%**************************************************************************
myncid  = netcdf.create('figure_s8.nc', 'NC_NOCLOBBER');
dimid1  = netcdf.defDim(myncid, 'lon', 144);
dimid2  = netcdf.defDim(myncid, 'lat', 72);
varid1  = netcdf.defVar(myncid, 'lon', 'double', [dimid1]);
varid2  = netcdf.defVar(myncid, 'lat', 'double', [dimid2]);
varid11  = netcdf.defVar(myncid, 'Me_trd_diff', 'double', [dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid11, Me_trd_diff);
netcdf.close(myncid);
