clear all
clc

diri_all = 'I:\WORKS\30-Comp_EPHH\CMIP6\historical\';
diri_nat = 'I:\WORKS\30-Comp_EPHH\CMIP6\hist-nat\';

models  = {'ACCESS-CM2','ACCESS-ESM1-5','CanESM5','CNRM-CM6-1',...
           'HadGEM3-GC31-LL','IPSL-CM6A-LR','MIROC6','MRI-ESM2-0','NorESM2-LM'};

lat     = ncread(strcat(diri_all,models{1},'_historical.nc'),'lat');
lon     = ncread(strcat(diri_all,models{1},'_historical.nc'),'lon');

for m = 1:length(models)
%ncdisp(strcat(diri,models{i},'_historical.nc'))
comp_pr_ann_all(:,:,:,m) = mean(ncread(strcat(diri_all,models{m},'_historical.nc'),'comp_pr_ann'),4);
comp_pr_ann_nat(:,:,:,m) = mean(ncread(strcat(diri_nat,models{m},'_hist-nat.nc'),'comp_pr_ann'),4);
disp(m)
end

comp_pr_ann_all = mean(comp_pr_ann_all,4);
comp_pr_ann_nat = mean(comp_pr_ann_nat,4);

comp_pr_ann     = comp_pr_ann_all(:,:,1:41)-comp_pr_ann_nat;

comp_pr_ann = reshape(comp_pr_ann,[144*72 41]);

landsea = ncread('I:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');
landsea = reshape(landsea,[144*72 1]);

prec = ncread('I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\MSWEPv2_prec_2p5deg.nc', 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*44),[144 72 365 43]),3),4); % 1980.1.1-2022.12.31
prec_clim = reshape(prec_clim,[144*72 1]);

lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);

lct     = find(landsea==1&prec_clim>100&lat1d>=-60);

comp_pr_ann_land = comp_pr_ann(lct,:);

comp_pr_ann_land = reshape(comp_pr_ann_land.*repmat(sqrt(cosd(lat1d(lct))),[1 41]),[length(lct) 1 41]);
%--------------------------------------------------------------------------
[eofs_pr,pcs_pr,expvar_pr] = eof(double(comp_pr_ann_land));
eof1_pr = eofs_pr(:,:,1).*(-1*std(pcs_pr(1,:)));
pc1_pr  = pcs_pr(1,:)/(-1*std(pcs_pr(1,:)));

lon1d   = lon1d(lct);
lat1d   = lat1d(lct);

eof1_pr_2d = zeros(size(lon2d));

for j = 1:length(lat)
    for i = 1:length(lon)
    lct = find(lon1d==lon2d(i,j)&lat1d==lat2d(i,j));

    if length(lct)>0
       eof1_pr_2d(i,j) = eof1_pr(lct);
    else
       eof1_pr_2d(i,j) = -999;
    end
    end
    disp(j)
end
%**************************************************************************
myncid  = netcdf.create('fig3a.nc', 'NC_NOCLOBBER');
dimid1  = netcdf.defDim(myncid, 'lon', 144);
dimid2  = netcdf.defDim(myncid, 'lat', 72);

varid1  = netcdf.defVar(myncid, 'lon', 'double', [dimid1]);
varid2  = netcdf.defVar(myncid, 'lat', 'double', [dimid2]);
varid3  = netcdf.defVar(myncid, 'eof1_pr_2d', 'double', [dimid1 dimid2]);
netcdf.endDef(myncid);

netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, eof1_pr_2d);
netcdf.close(myncid);






