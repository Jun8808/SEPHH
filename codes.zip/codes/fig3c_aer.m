% 2.5 deg, 1981-2020, Theil-Sen 
clear all
clc

diri = 'I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\';
lon  = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'lon'); 
lat  = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'lat');
prec = ncread(strcat(diri, 'MSWEPv2_prec_2p5deg.nc'), 'prec');

pts  = 95; %%%%

lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);
%--------------------------------------------------------------------------
landsea = ncread('I:\WORKS\30-Comp_EPHH\figure1\land_sea_mask.nc','landsea');
landsea = reshape(landsea,[144*72 1]);

prec = ncread('I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\MSWEPv2_prec_2p5deg.nc', 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*44),[144 72 365 43]),3),4); % 1980.1.1-2022.12.31
prec_clim = reshape(prec_clim,[144*72 1]);
%--------------------------------------------------------------------------
diri_all = 'I:\WORKS\30-Comp_EPHH\CMIP6\historical\';
diri_nat = 'I:\WORKS\30-Comp_EPHH\CMIP6\hist-nat\';

models  = {'ACCESS-CM2','ACCESS-ESM1-5','CanESM5','CNRM-CM6-1',...
           'HadGEM3-GC31-LL','IPSL-CM6A-LR','MIROC6','MRI-ESM2-0','NorESM2-LM'};

lat     = ncread(strcat(diri_all,models{1},'_historical.nc'),'lat');
lon     = ncread(strcat(diri_all,models{1},'_historical.nc'),'lon');

for m = 1:length(models)
%ncdisp(strcat(diri,models{i},'_historical.nc'))
comp_pr_ann_all(:,:,:,m) = mean(ncread(strcat(diri_all,models{m},'_historical.nc'),'comp_pr_ann'),4);
comp_pr_ann_nat(:,:,:,m) = mean(ncread(strcat(diri_nat,models{m},'_hist-nat.nc'),'comp_pr_ann'),4);
disp(m)
end

comp_pr_ann_all = mean(comp_pr_ann_all,4);
comp_pr_ann_nat = mean(comp_pr_ann_nat,4);

comp_pr_ann     = comp_pr_ann_all(:,:,1:41)-comp_pr_ann_nat;

comp_pr_ann = reshape(comp_pr_ann,[144*72 41]);

comp_pr_ann_all = reshape(comp_pr_ann_all(:,:,1:43),[144*72 43]);

prec = ncread('I:\WORKS\30-Comp_EPHH\MSWEPv2_Daily_2p5deg\MSWEPv2_prec_2p5deg.nc', 'prec');
prec_clim = mean(sum(reshape(prec(:,:,365*1+1:365*44),[144 72 365 43]),3),4); % 1980.1.1-2022.12.31
prec_clim = reshape(prec_clim,[144*72 1]);

lct     = find(landsea==1&prec_clim>100&lat1d>=-60);

comp_pr_ann_land = comp_pr_ann(lct,:);

comp_pr_ann_all_land = comp_pr_ann_all(lct,:);

lon2d  = repmat(lon,[1 length(lat)]);
lat2d  = repmat(lat,[1 length(lon)])';
lon1d  = reshape(lon2d,[144*72 1]);
lat1d  = reshape(lat2d,[144*72 1]);

comp_pr_ann_land2 = reshape(comp_pr_ann_land.*repmat(sqrt(cosd(lat1d(lct))),[1 41]),[length(lct) 1 41]);

[eofs_pr,pcs_pr,expvar_pr] = eof(double(comp_pr_ann_land2));
eof1_pr = eofs_pr(:,:,1).*(-1*std(pcs_pr(1,:)));
pc1_pr  = pcs_pr(1,:)/(-1*std(pcs_pr(1,:)));

clear comp_pr comp_pr_ann comp_pr_land comp_pr_ann_land2
%--------------------------------------------------------------------------
diri    = 'I:\WORKS\30-Comp_EPHH\CMIP6\hist-aer\';

models  = {'ACCESS-CM2','ACCESS-ESM1-5','CanESM5','CNRM-CM6-1',...
           'HadGEM3-GC31-LL','IPSL-CM6A-LR','MIROC6','MRI-ESM2-0','NorESM2-LM'};

lat     = ncread(strcat(diri,models{1},'_hist-aer.nc'),'lat');
lon     = ncread(strcat(diri,models{1},'_hist-aer.nc'),'lon');

for m = 1:length(models)
%ncdisp(strcat(diri,models{i},'_historical.nc'))
comp_pr_ann(:,:,:,m) = mean(ncread(strcat(diri,models{m},'_hist-aer.nc'),'comp_pr_ann'),4);
disp(m)
end

comp_pr_ann = mean(comp_pr_ann,4);

comp_pr_ann = reshape(comp_pr_ann,[144*72 41]);

comp_pr_ann_land = comp_pr_ann(lct,:);

clear comp_pr comp_pr_ann

num_mem = 1;

for m = 1:length(models)
comp_pr_ann = ncread(strcat(diri,models{m},'_hist-aer.nc'),'comp_pr_ann');    
comp_pr_ann_member(:,:,:,num_mem:num_mem+size(comp_pr_ann,4)-1) = comp_pr_ann;
num_mem  = num_mem + size(comp_pr_ann,4);
disp(m)
clear comp_pr_ann
end

comp_pr_ann_member = reshape(comp_pr_ann_member,[144*72 41 40]);
comp_pr_ann_member = comp_pr_ann_member(lct,:,:);
%--------------------------------------------------------------------------
for k = 1:41
cov_pr = cov(eof1_pr,comp_pr_ann_land(:,k));
cov_pr_mme(k) = cov_pr(2,1);
clear cov_pr
disp(k)
end

for k = 1:41
for i = 1:40
cov_pr = cov(eof1_pr,comp_pr_ann_member(:,k,i));
cov_pr_member(k,i) = cov_pr(2,1);
clear cov_pr
end
end

for yr = 1:32
b = polyfit(1:9+yr,cov_pr_mme(1:9+yr),1);
sig_pr_mme(yr) = b(1);
end

for yr = 1:32
for i = 1:40
b = polyfit(1:9+yr,cov_pr_member(1:9+yr,i),1);
sig_pr_member(yr,i) = b(1);
end
end

% for i = 1:40
% plot(sig_pr_member(:,i))
% title(num2str(i))
% pause(1)
% end
%**************************************************************************
myncid  = netcdf.create('fig3c_aer.nc', 'NC_NOCLOBBER');
dimid1  = netcdf.defDim(myncid, 'year', 32);
dimid2  = netcdf.defDim(myncid, 'mem', 40);

varid1  = netcdf.defVar(myncid, 'sig_pr_mme', 'double', [dimid1]);
varid2  = netcdf.defVar(myncid, 'sig_pr_member', 'double', [dimid1 dimid2]);
netcdf.endDef(myncid);

netcdf.putVar(myncid, varid1, sig_pr_mme);
netcdf.putVar(myncid, varid2, sig_pr_member);
netcdf.close(myncid);
