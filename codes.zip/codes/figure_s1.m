clear all
clc

diri = 'I:\WORKS\30-Comp_EPHH\figure_s1\'; 
fn   = 'public_emdat_custom_request_2024-06-23_ebe193b9-4f20-44fe-962b-1f3ebf8ec5f4.xlsx';
[data,txt] = xlsread(strcat(diri,fn));

txt   = txt(8:end,:);
year  = data(:,8);
dias  = txt(:,7);
cont  = txt(:,14);
death = data(:,14);

uniq_dias = unique(dias);
uniq_dias = uniq_dias([2,3,7,6,1,8]);

uniq_cont = unique(cont);

years = 1981:2020;
dias_num  =  zeros(length(uniq_dias),length(uniq_cont),length(years));
death_num =  zeros(length(uniq_dias),length(uniq_cont),length(years));

for y = 1:length(years)
    lcty   = find(year==years(y));
    conty  = cont(lcty);
    diasy  = dias(lcty);
    deathy = death(lcty);

    for c = 1:length(uniq_cont)
        lctc   = find(strcmp(conty,uniq_cont{c})==1);
        diasc  = diasy(lctc);
        deathc = deathy(lctc);

        for d = 1:length(uniq_dias)
            lctd  = find(strcmp(diasc,uniq_dias{d})==1);
            dias_num(d,c,y)  = length(lctd);
            death_num(d,c,y) = sum(deathc(lctd),'omitnan');
            clear lctd
        end
        clear lctc diasc

     end
     clear lcty conty diasy deathy
     disp(y)
end

%sum(sum(sum(dias_num)));
%sum(sum(sum(death_num)));
%**************************************************************************
myncid = netcdf.create('figure_s1.nc', 'NC_NOCLOBBER');
dimid0 = netcdf.defDim(myncid, 'disaster', length(uniq_dias));
dimid1 = netcdf.defDim(myncid, 'continent', length(uniq_cont));
dimid2 = netcdf.defDim(myncid, 'decade', 8);
varid1 = netcdf.defVar(myncid, 'dias_cont', 'double', [dimid0 dimid1]);
varid2 = netcdf.defVar(myncid, 'death_cont', 'double', [dimid0 dimid1]);
varid3 = netcdf.defVar(myncid, 'dias_decade', 'double', [dimid0 dimid2]);
varid4 = netcdf.defVar(myncid, 'death_decade', 'double', [dimid0 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, sum(dias_num,3));
netcdf.putVar(myncid, varid2, sum(death_num,3));
netcdf.putVar(myncid, varid3, squeeze(sum(reshape(squeeze(sum(dias_num,2)),[length(uniq_dias) 5 8]),2)));
netcdf.putVar(myncid, varid4, squeeze(sum(reshape(squeeze(sum(death_num,2)),[length(uniq_dias) 5 8]),2)));
netcdf.close(myncid);

